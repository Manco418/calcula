#include <stdio.h>

int main (){


int numero [10], quadrado [10];

printf("Digite dez números inteiros:");
scanf("%d", &numero[0]);
scanf("%d", &numero[1]);
scanf("%d", &numero[2]);
scanf("%d", &numero[3]);
scanf("%d", &numero[4]);
scanf("%d", &numero[5]);
scanf("%d", &numero[6]);
scanf("%d", &numero[7]);
scanf("%d", &numero[8]);
scanf("%d", &numero[9]);

 for (int i = 0; i < 10; ++i) {  
  quadrado [i] = numero [i] * numero [i];
 }
printf("Valores digitados:\n");
for (int i = 0; i < 10; ++i){
  printf("%d\n", numero[i]);
}

printf("\n Quadrado dos valores:\n");
for (int i = 0; i < 10; ++i){
  printf("%d\n", quadrado[i]);
}
return 0;
}